# Car Damage Model Benchmark Bundle

Contains PyTorch, ONNX and TFLite/LiteRT exports from the same fine-tuned checkpoint.

- models/: model artifacts
- dataset/images/val/: validation images
- dataset/labels/val/: YOLO ground-truth labels
- dataset/data.yaml: portable dataset configuration
- benchmark/latency_50_images.txt: fixed latency sample
- benchmark/benchmark_config.json: initial evaluation settings

Before comparing formats:
1. Confirm class order and model output shapes.
2. Verify preprocessing, confidence threshold and NMS behavior.
3. Separate model loading and warm-up from steady-state latency.
4. Measure mean, median, P90, P95 latency and throughput.
5. Evaluate mAP50, mAP50-95, precision, recall and per-class AP on the same labeled validation images.
6. Report missing labels and any unsupported runtime operations.
